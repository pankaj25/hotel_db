import React from "react";

export const ListRow = (props) => {
  const { transaction } = props;
  return (
    <tr>
      <td>{transaction.refNo}</td>
      <td>{transaction.rateId}</td>
      <td>{transaction.UserId}</td>
      <td>{transaction.totalRate}</td>
      <td>{transaction.baseRate}</td>
      <td>{transaction.currency}</td>
      <td>{transaction.providerId}</td>
      <td>{transaction.status}</td>
      <td>
          {transaction.Commissions.map( (Commission) => (
              <tr>
              <td>{Commission.amount}</td>
              <td>{Commission.description}</td>
              <td>{Commission.type}</td>
              </tr>
          ))}
      </td>
      <td style={{border:"none !important", padding: "0px !important"}}>
          {transaction.Taxes.map( (Tax) => (
              <tr>
              <td>{Tax.amount}</td>
              <td>{Tax.description}</td>
              <td>{Tax.type}</td>
              </tr>
          ))}
      </td>
      <td>{transaction.refundable?"Yes":"No"}</td>
      <td>{transaction.depositRequired?"Yes":"No"}</td>
      <td>{transaction.guaranteeRequired?"Yes":"No"}</td>
      <td>{transaction.onlineCancellable?"Yes":"No"}</td>
      <td>{transaction.payAtHotel?"Yes":"No"}</td>
    </tr>
  )
}
